# Intelli-NIET Campus Issue System

This repository is now integrated as a full working model:
- MySQL database (schema + seed data)
- Spring Boot backend API (`backend`)
- Static frontend (`frontend`) with real backend login

## 1) Prerequisites

- Java 17+
- Maven 3.9+
- MySQL 8+
- Any static file server (VS Code Live Server or Python `http.server`)

## 2) Database setup

Create database:

```sql
CREATE DATABASE campus_issue_db;
```

Import dump from:
- `database/campus_issue_db_dump.sql`

Optional: run
- `database/frontend_backend_sync.sql`

## 3) Backend setup

Update DB credentials in:
- `backend/src/main/resources/application.properties`

Default backend port:
- `8081`

Run backend:

```bash
cd backend
mvn spring-boot:run
```

## 4) Frontend setup

Serve frontend directory over HTTP:

```bash
cd frontend
python -m http.server 5500
```

Then open:
- `http://localhost:5500/login.html`

## 5) Login behavior

- Login page now calls `POST /api/auth/login`.
- Role tab check is enforced:
  - Admin tab accepts only backend role `admin`
  - Faculty tab accepts only backend role `faculty`
- On success, token + role + display name are stored in local storage.
- Dashboards are route-guarded (redirect to login if not authenticated).

## 6) Test flow

1. Start MySQL and import SQL.
2. Start backend on `http://localhost:8081`.
3. Start frontend server on `http://localhost:5500`.
4. Sign in from `login.html` using a valid user from database.
5. Confirm redirects:
   - Admin users -> `admin.html`
   - Teacher users -> `faculty.html`

## Notes

- Backend CORS is enabled for local frontend development.
- Existing dashboard data remains sample/static UI data; authentication flow is now fully integrated.
