package com.niet.campusissuesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusissuesystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
