package com.niet.campusissuesystem.enums;

public enum Role {
    ADMIN,
    TEACHER
}