package com.niet.campusissuesystem.entity;

import com.niet.campusissuesystem.enums.ComplaintStatus;
import com.niet.campusissuesystem.enums.Priority;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "complaints")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "complaint_id")
    private Long complaintId;

    @Column(name = "complaint_title", nullable = false, length = 200)
    private String complaintTitle;

    @Column(name = "complaint_description", nullable = false, columnDefinition = "TEXT")
    private String complaintDescription;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private IssueCategory category;

    @ManyToOne
    @JoinColumn(name = "location_id", nullable = false)
    private Location location;

    @ManyToOne
    @JoinColumn(name = "reported_by", nullable = false)
    private User reportedBy;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority = Priority.MEDIUM;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComplaintStatus status = ComplaintStatus.SUBMITTED;

    @Column(name = "assigned_department", length = 100)
    private String assignedDepartment;

    @Column(name = "expected_resolution_days")
    private Integer expectedResolutionDays;

    @Column(name = "expected_resolution_date")
    private LocalDate expectedResolutionDate;

    @Column(name = "actual_resolution_date")
    private LocalDate actualResolutionDate;

    @Column(name = "admin_remark", columnDefinition = "TEXT")
    private String adminRemark;

    @Column(name = "is_verified")
    private Boolean isVerified = false;

    @Column(name = "custom_category", length = 150)
    private String customCategory;

    @Column(name = "area_type", length = 100)
    private String areaType;

    @Column(name = "landmark", length = 255)
    private String landmark;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}