package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.Complaint;
import com.niet.campusissuesystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import com.niet.campusissuesystem.enums.ComplaintStatus;

import java.time.LocalDate;
import java.util.List;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {
    List<Complaint> findByReportedBy(User user);
    List<Complaint> findByExpectedResolutionDateBeforeAndStatusNot(LocalDate date, ComplaintStatus status);
}