package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.IssueCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IssueCategoryRepository extends JpaRepository<IssueCategory, Long> {
    java.util.Optional<IssueCategory> findByCategoryNameIgnoreCase(String categoryName);
}