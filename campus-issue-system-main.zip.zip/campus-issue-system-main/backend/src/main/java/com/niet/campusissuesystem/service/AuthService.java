package com.niet.campusissuesystem.service;

import com.niet.campusissuesystem.dto.LoginRequestDto;
import com.niet.campusissuesystem.entity.User;
import com.niet.campusissuesystem.repository.UserRepository;
import com.niet.campusissuesystem.security.JwtUtil;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Locale;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository,
                       JwtUtil jwtUtil,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = passwordEncoder;
    }
    public User login(LoginRequestDto dto) {
        String identity = dto.getUsername() != null && !dto.getUsername().isBlank()
                ? dto.getUsername().trim()
                : dto.getEmail();

        if (identity == null || identity.isBlank()) {
            throw new RuntimeException("Username or email is required");
        }

        User user;
        if (identity.contains("@")) {
            user = userRepository.findByEmail(identity)
                    .orElseThrow(() -> new RuntimeException("User not found"));
        } else {
            user = userRepository.findByUsernameIgnoreCase(identity.toLowerCase(Locale.ROOT))
                    .orElseThrow(() -> new RuntimeException("User not found"));
        }

        if (!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return user;
    }
}