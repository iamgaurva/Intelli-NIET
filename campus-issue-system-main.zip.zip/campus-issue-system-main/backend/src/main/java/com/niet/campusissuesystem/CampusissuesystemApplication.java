package com.niet.campusissuesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusissuesystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusissuesystemApplication.class, args);
	}

}
