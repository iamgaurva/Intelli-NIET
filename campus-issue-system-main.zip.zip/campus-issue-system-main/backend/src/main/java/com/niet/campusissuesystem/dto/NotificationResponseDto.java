package com.niet.campusissuesystem.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class NotificationResponseDto {

    private Long notificationId;
    private Long complaintId;
    private String notificationTitle;
    private String message;
    private String notificationType;
    private Boolean isRead;
    private LocalDateTime createdAt;
}