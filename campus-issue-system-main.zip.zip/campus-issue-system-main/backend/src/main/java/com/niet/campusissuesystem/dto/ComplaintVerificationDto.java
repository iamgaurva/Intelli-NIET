package com.niet.campusissuesystem.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintVerificationDto {
    private String comments;
}