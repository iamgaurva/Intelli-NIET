package com.niet.campusissuesystem.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "locations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Location {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "location_id")
    private Long locationId;

    @Column(name = "block_name", nullable = false, length = 50)
    private String blockName;

    @Column(length = 20)
    private String floor;

    @Column(name = "room_number", length = 20)
    private String roomNumber;

    @Column(name = "lab_name", length = 100)
    private String labName;

    @Column(name = "location_description", length = 255)
    private String locationDescription;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}