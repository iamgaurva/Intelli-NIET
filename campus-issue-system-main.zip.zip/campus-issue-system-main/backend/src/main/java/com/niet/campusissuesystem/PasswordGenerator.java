package com.niet.campusissuesystem;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordGenerator {

    public static void main(String[] args) {

        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

        String adminPassword = encoder.encode("admin123");
        String teacherPassword = encoder.encode("teacher123");

        System.out.println("Admin Encrypted Password: " + adminPassword);
        System.out.println("Teacher Encrypted Password: " + teacherPassword);
    }
}