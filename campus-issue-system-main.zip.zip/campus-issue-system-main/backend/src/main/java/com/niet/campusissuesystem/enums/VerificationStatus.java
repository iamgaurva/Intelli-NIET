package com.niet.campusissuesystem.enums;

public enum VerificationStatus {
    VERIFIED,
    REOPENED
}