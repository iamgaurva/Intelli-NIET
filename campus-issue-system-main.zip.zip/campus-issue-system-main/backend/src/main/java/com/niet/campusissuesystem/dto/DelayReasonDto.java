package com.niet.campusissuesystem.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DelayReasonDto {

    @NotBlank(message = "Delay reason is required")
    private String reason;

    @NotNull(message = "Additional expected days is required")
    @Min(value = 1, message = "Additional expected days must be at least 1")
    private Integer additionalDays;
}