package com.niet.campusissuesystem.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}