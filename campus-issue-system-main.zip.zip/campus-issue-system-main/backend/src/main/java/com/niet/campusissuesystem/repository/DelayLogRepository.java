package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.DelayLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DelayLogRepository extends JpaRepository<DelayLog, Long> {
    List<DelayLog> findByComplaint_ComplaintId(Long complaintId);
}