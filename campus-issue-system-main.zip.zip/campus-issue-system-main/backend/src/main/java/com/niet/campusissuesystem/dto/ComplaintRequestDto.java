package com.niet.campusissuesystem.dto;

import com.niet.campusissuesystem.enums.Priority;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintRequestDto {

    @NotBlank(message = "Complaint title is required")
    private String complaintTitle;

    @NotBlank(message = "Complaint description is required")
    private String complaintDescription;

    private Long categoryId;

    private Long locationId;

    private String categoryName;
    private String blockName;
    private String floor;
    private String roomNumber;
    private String areaType;
    private String landmark;

    private Priority priority;

    private String customCategory;
}