package com.niet.campusissuesystem.controller;

import com.niet.campusissuesystem.dto.NotificationResponseDto;
import com.niet.campusissuesystem.service.ComplaintService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final ComplaintService complaintService;

    public NotificationController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    @GetMapping("/my")
    public ResponseEntity<List<NotificationResponseDto>> getMyNotifications() {
        return ResponseEntity.ok(complaintService.getMyNotifications());
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<NotificationResponseDto> markNotificationAsRead(@PathVariable Long id) {
        return ResponseEntity.ok(complaintService.markNotificationAsRead(id));
    }
}