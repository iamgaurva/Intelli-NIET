package com.niet.campusissuesystem.dto;

import com.niet.campusissuesystem.enums.ComplaintStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintStatusUpdateDto {

    @NotNull(message = "New status is required")
    private ComplaintStatus newStatus;

    private String remarks;
}