package com.niet.campusissuesystem.controller;

import com.niet.campusissuesystem.dto.ComplaintImageResponseDto;
import com.niet.campusissuesystem.dto.ComplaintRequestDto;
import com.niet.campusissuesystem.dto.ComplaintResponseDto;
import com.niet.campusissuesystem.dto.ComplaintScheduleUpdateDto;
import com.niet.campusissuesystem.dto.ComplaintStatusUpdateDto;
import com.niet.campusissuesystem.dto.ComplaintVerificationDto;
import com.niet.campusissuesystem.dto.DelayReasonDto;
import com.niet.campusissuesystem.service.ComplaintService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/complaints")
public class ComplaintController {

    private final ComplaintService complaintService;

    public ComplaintController(ComplaintService complaintService) {
        this.complaintService = complaintService;
    }

    @PostMapping
    public ResponseEntity<ComplaintResponseDto> createComplaint(@Valid @RequestBody ComplaintRequestDto requestDto) {
        return ResponseEntity.ok(complaintService.createComplaint(requestDto));
    }

    @GetMapping
    public ResponseEntity<List<ComplaintResponseDto>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @GetMapping("/my")
    public ResponseEntity<List<ComplaintResponseDto>> getMyComplaints() {
        return ResponseEntity.ok(complaintService.getMyComplaints());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplaintResponseDto> getComplaintById(@PathVariable Long id) {
        return ResponseEntity.ok(complaintService.getComplaintById(id));
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<ComplaintResponseDto> updateComplaintStatus(@PathVariable Long id,
                                                                      @Valid @RequestBody ComplaintStatusUpdateDto dto) {
        return ResponseEntity.ok(complaintService.updateComplaintStatus(id, dto));
    }

    @PutMapping("/{id}/verify")
    public ResponseEntity<ComplaintResponseDto> verifyComplaint(@PathVariable Long id,
                                                                @Valid @RequestBody ComplaintVerificationDto dto) {
        return ResponseEntity.ok(complaintService.verifyComplaint(id, dto));
    }

    @PutMapping("/{id}/reopen")
    public ResponseEntity<ComplaintResponseDto> reopenComplaint(@PathVariable Long id,
                                                                @Valid @RequestBody ComplaintVerificationDto dto) {
        return ResponseEntity.ok(complaintService.reopenComplaint(id, dto));
    }

    @PutMapping("/{id}/schedule")
    public ResponseEntity<ComplaintResponseDto> setExpectedResolutionDays(@PathVariable Long id,
                                                                          @Valid @RequestBody ComplaintScheduleUpdateDto dto) {
        return ResponseEntity.ok(complaintService.setExpectedResolutionDays(id, dto));
    }

    @PutMapping("/{id}/delay")
    public ResponseEntity<ComplaintResponseDto> markComplaintDelayed(@PathVariable Long id,
                                                                     @Valid @RequestBody DelayReasonDto dto) {
        return ResponseEntity.ok(complaintService.markComplaintDelayed(id, dto));
    }

    @GetMapping("/overdue")
    public ResponseEntity<List<ComplaintResponseDto>> getOverdueComplaints() {
        return ResponseEntity.ok(complaintService.getOverdueComplaints());
    }

    @PostMapping("/{id}/upload-image")
    public ResponseEntity<ComplaintImageResponseDto> uploadComplaintImage(@PathVariable Long id,
                                                                          @RequestParam("file") MultipartFile file) {
        return ResponseEntity.ok(complaintService.uploadComplaintImage(id, file));
    }

    @GetMapping("/{id}/images")
    public ResponseEntity<List<ComplaintImageResponseDto>> getComplaintImages(@PathVariable Long id) {
        return ResponseEntity.ok(complaintService.getComplaintImages(id));
    }
}