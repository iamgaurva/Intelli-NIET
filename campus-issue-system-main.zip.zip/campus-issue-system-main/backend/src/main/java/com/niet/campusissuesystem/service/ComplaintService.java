package com.niet.campusissuesystem.service;

import com.niet.campusissuesystem.dto.ComplaintImageResponseDto;
import com.niet.campusissuesystem.dto.ComplaintRequestDto;
import com.niet.campusissuesystem.dto.ComplaintResponseDto;
import com.niet.campusissuesystem.dto.ComplaintScheduleUpdateDto;
import com.niet.campusissuesystem.dto.ComplaintStatusUpdateDto;
import com.niet.campusissuesystem.dto.ComplaintVerificationDto;
import com.niet.campusissuesystem.dto.DelayReasonDto;
import com.niet.campusissuesystem.dto.NotificationResponseDto;
import com.niet.campusissuesystem.entity.Complaint;
import com.niet.campusissuesystem.entity.ComplaintImage;
import com.niet.campusissuesystem.entity.ComplaintStatusHistory;
import com.niet.campusissuesystem.entity.DelayLog;
import com.niet.campusissuesystem.entity.IssueCategory;
import com.niet.campusissuesystem.entity.Location;
import com.niet.campusissuesystem.entity.Notification;
import com.niet.campusissuesystem.entity.User;
import com.niet.campusissuesystem.entity.VerificationLog;
import com.niet.campusissuesystem.enums.ComplaintStatus;
import com.niet.campusissuesystem.enums.Priority;
import com.niet.campusissuesystem.enums.Role;
import com.niet.campusissuesystem.enums.VerificationStatus;
import com.niet.campusissuesystem.repository.ComplaintImageRepository;
import com.niet.campusissuesystem.repository.ComplaintRepository;
import com.niet.campusissuesystem.repository.ComplaintStatusHistoryRepository;
import com.niet.campusissuesystem.repository.DelayLogRepository;
import com.niet.campusissuesystem.repository.IssueCategoryRepository;
import com.niet.campusissuesystem.repository.LocationRepository;
import com.niet.campusissuesystem.repository.NotificationRepository;
import com.niet.campusissuesystem.repository.UserRepository;
import com.niet.campusissuesystem.repository.VerificationLogRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final IssueCategoryRepository issueCategoryRepository;
    private final LocationRepository locationRepository;
    private final UserRepository userRepository;
    private final ComplaintStatusHistoryRepository complaintStatusHistoryRepository;
    private final VerificationLogRepository verificationLogRepository;
    private final DelayLogRepository delayLogRepository;
    private final NotificationRepository notificationRepository;
    private final ComplaintImageRepository complaintImageRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;

    public ComplaintService(ComplaintRepository complaintRepository,
                            IssueCategoryRepository issueCategoryRepository,
                            LocationRepository locationRepository,
                            UserRepository userRepository,
                            ComplaintStatusHistoryRepository complaintStatusHistoryRepository,
                            VerificationLogRepository verificationLogRepository,
                            DelayLogRepository delayLogRepository,
                            NotificationRepository notificationRepository,
                            ComplaintImageRepository complaintImageRepository) {
        this.complaintRepository = complaintRepository;
        this.issueCategoryRepository = issueCategoryRepository;
        this.locationRepository = locationRepository;
        this.userRepository = userRepository;
        this.complaintStatusHistoryRepository = complaintStatusHistoryRepository;
        this.verificationLogRepository = verificationLogRepository;
        this.delayLogRepository = delayLogRepository;
        this.notificationRepository = notificationRepository;
        this.complaintImageRepository = complaintImageRepository;
    }

    private User getCurrentLoggedInUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || authentication.getName() == null) {
            throw new RuntimeException("No authenticated user found");
        }

        String email = authentication.getName();

        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }

    private User getAdminUser() {
        return userRepository.findByEmail("admin@niet.co.in")
                .orElseThrow(() -> new RuntimeException("Admin user not found"));
    }

    private ComplaintResponseDto mapToComplaintResponseDto(Complaint complaint) {
        return ComplaintResponseDto.builder()
                .complaintId(complaint.getComplaintId())
                .complaintCode(String.format("CMP-%03d", complaint.getComplaintId()))
                .complaintTitle(complaint.getComplaintTitle())
                .complaintDescription(complaint.getComplaintDescription())

                .categoryId(complaint.getCategory().getCategoryId())
                .categoryName(complaint.getCategory().getCategoryName())

                .locationId(complaint.getLocation().getLocationId())
                .blockName(complaint.getLocation().getBlockName())
                .floor(complaint.getLocation().getFloor())
                .roomNumber(complaint.getLocation().getRoomNumber())
                .areaType(complaint.getAreaType())
                .landmark(complaint.getLandmark())

                .reportedByUserId(complaint.getReportedBy().getUserId())
                .reportedByName(complaint.getReportedBy().getFullName())
                .reportedByEmail(complaint.getReportedBy().getEmail())
                .reportedByRole(complaint.getReportedBy().getRole().name())

                .priority(complaint.getPriority().name())
                .status(complaint.getStatus().name())
                .assignedDepartment(complaint.getAssignedDepartment())

                .expectedResolutionDays(complaint.getExpectedResolutionDays())
                .expectedResolutionDate(complaint.getExpectedResolutionDate())
                .actualResolutionDate(complaint.getActualResolutionDate())

                .adminRemark(complaint.getAdminRemark())
                .isVerified(complaint.getIsVerified())
                .customCategory(complaint.getCustomCategory())

                .createdAt(complaint.getCreatedAt())
                .updatedAt(complaint.getUpdatedAt())
                .build();
    }

    private IssueCategory resolveCategory(ComplaintRequestDto requestDto) {
        if (requestDto.getCategoryId() != null) {
            return issueCategoryRepository.findById(requestDto.getCategoryId())
                    .orElseThrow(() -> new RuntimeException("Category not found"));
        }

        String incomingName = requestDto.getCategoryName() != null
                ? requestDto.getCategoryName().trim()
                : "";

        if (incomingName.isBlank()) {
            throw new RuntimeException("Category is required");
        }

        return issueCategoryRepository.findByCategoryNameIgnoreCase(incomingName)
                .orElseGet(() -> issueCategoryRepository.save(
                        IssueCategory.builder()
                                .categoryName(incomingName)
                                .isActive(true)
                                .build()
                ));
    }

    private Location resolveLocation(ComplaintRequestDto requestDto) {
        if (requestDto.getLocationId() != null) {
            return locationRepository.findById(requestDto.getLocationId())
                    .orElseThrow(() -> new RuntimeException("Location not found"));
        }

        String block = requestDto.getBlockName() != null ? requestDto.getBlockName().trim() : "";
        String floor = requestDto.getFloor() != null ? requestDto.getFloor().trim() : "";
        String room = requestDto.getRoomNumber() != null ? requestDto.getRoomNumber().trim() : "";

        if (block.isBlank() || floor.isBlank() || room.isBlank()) {
            throw new RuntimeException("Block, floor, and room are required");
        }

        return locationRepository.findByBlockNameIgnoreCaseAndFloorIgnoreCaseAndRoomNumberIgnoreCase(block, floor, room)
                .orElseGet(() -> locationRepository.save(
                        Location.builder()
                                .blockName(block)
                                .floor(floor)
                                .roomNumber(room)
                                .locationDescription(requestDto.getLandmark())
                                .build()
                ));
    }

    private NotificationResponseDto mapToNotificationResponseDto(Notification notification) {
        return NotificationResponseDto.builder()
                .notificationId(notification.getNotificationId())
                .complaintId(notification.getComplaint() != null ? notification.getComplaint().getComplaintId() : null)
                .notificationTitle(notification.getNotificationTitle())
                .message(notification.getMessage())
                .notificationType(notification.getNotificationType())
                .isRead(notification.getIsRead())
                .createdAt(notification.getCreatedAt())
                .build();
    }

    private ComplaintImageResponseDto mapToComplaintImageResponseDto(ComplaintImage complaintImage) {
        return ComplaintImageResponseDto.builder()
                .imageId(complaintImage.getImageId())
                .complaintId(complaintImage.getComplaint().getComplaintId())
                .imagePath(complaintImage.getImagePath())
                .uploadedAt(complaintImage.getUploadedAt())
                .build();
    }

    private void createNotification(User user, Complaint complaint, String title, String message, String type) {
        Notification notification = Notification.builder()
                .user(user)
                .complaint(complaint)
                .notificationTitle(title)
                .message(message)
                .notificationType(type)
                .isRead(false)
                .build();

        notificationRepository.save(notification);
    }

    public ComplaintResponseDto createComplaint(ComplaintRequestDto requestDto) {
        User user = getCurrentLoggedInUser();

        if (user.getRole() != Role.TEACHER) {
            throw new RuntimeException("Only teachers can create complaints");
        }

        IssueCategory category = resolveCategory(requestDto);
        Location location = resolveLocation(requestDto);

        Complaint complaint = Complaint.builder()
                .complaintTitle(requestDto.getComplaintTitle())
                .complaintDescription(requestDto.getComplaintDescription())
                .category(category)
                .location(location)
                .reportedBy(user)
                .priority(requestDto.getPriority() != null ? requestDto.getPriority() : Priority.MEDIUM)
                .status(ComplaintStatus.SUBMITTED)
                .customCategory(requestDto.getCustomCategory())
                .areaType(requestDto.getAreaType())
                .landmark(requestDto.getLandmark())
                .isVerified(false)
                .build();

        Complaint savedComplaint = complaintRepository.save(complaint);

        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaint(savedComplaint)
                .oldStatus(null)
                .newStatus(ComplaintStatus.SUBMITTED.name())
                .changedBy(user)
                .remarks("Complaint created")
                .build();

        complaintStatusHistoryRepository.save(history);

        createNotification(
                getAdminUser(),
                savedComplaint,
                "New Complaint Raised",
                "A new complaint has been raised by " + user.getFullName(),
                "COMPLAINT_CREATED"
        );

        return mapToComplaintResponseDto(savedComplaint);
    }

    public List<ComplaintResponseDto> getAllComplaints() {
        return complaintRepository.findAll()
                .stream()
                .map(this::mapToComplaintResponseDto)
                .toList();
    }

    public ComplaintResponseDto getComplaintById(Long complaintId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        return mapToComplaintResponseDto(complaint);
    }

    public List<ComplaintResponseDto> getMyComplaints() {
        User user = getCurrentLoggedInUser();

        if (user.getRole() != Role.TEACHER) {
            throw new RuntimeException("Only teachers can view their own complaints");
        }

        return complaintRepository.findByReportedBy(user)
                .stream()
                .map(this::mapToComplaintResponseDto)
                .toList();
    }

    public ComplaintResponseDto updateComplaintStatus(Long complaintId, ComplaintStatusUpdateDto dto) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User changedBy = getCurrentLoggedInUser();

        if (changedBy.getRole() != Role.ADMIN) {
            throw new RuntimeException("Only admin can update complaint status");
        }

        String oldStatus = complaint.getStatus().name();
        String newStatus = dto.getNewStatus().name();

        complaint.setStatus(dto.getNewStatus());

        if (dto.getRemarks() != null && !dto.getRemarks().trim().isEmpty()) {
            complaint.setAdminRemark(dto.getRemarks());
        }

        if (dto.getNewStatus() == ComplaintStatus.RESOLVED) {
            complaint.setActualResolutionDate(LocalDate.now());
        }

        Complaint updatedComplaint = complaintRepository.save(complaint);

        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaint(updatedComplaint)
                .oldStatus(oldStatus)
                .newStatus(newStatus)
                .changedBy(changedBy)
                .remarks(dto.getRemarks())
                .build();

        complaintStatusHistoryRepository.save(history);

        createNotification(
                updatedComplaint.getReportedBy(),
                updatedComplaint,
                "Complaint Status Updated",
                "Your complaint status has been updated to " + updatedComplaint.getStatus().name(),
                "STATUS_UPDATED"
        );

        return mapToComplaintResponseDto(updatedComplaint);
    }

    public ComplaintResponseDto verifyComplaint(Long complaintId, ComplaintVerificationDto dto) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User verifiedBy = getCurrentLoggedInUser();

        if (verifiedBy.getRole() != Role.TEACHER) {
            throw new RuntimeException("Only teachers can verify complaints");
        }

        String oldStatus = complaint.getStatus().name();

        complaint.setStatus(ComplaintStatus.CLOSED);
        complaint.setIsVerified(true);

        Complaint updatedComplaint = complaintRepository.save(complaint);

        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaint(updatedComplaint)
                .oldStatus(oldStatus)
                .newStatus(ComplaintStatus.CLOSED.name())
                .changedBy(verifiedBy)
                .remarks(dto.getComments())
                .build();

        complaintStatusHistoryRepository.save(history);

        VerificationLog verificationLog = VerificationLog.builder()
                .complaint(updatedComplaint)
                .verifiedBy(verifiedBy)
                .verificationStatus(VerificationStatus.VERIFIED)
                .comments(dto.getComments())
                .build();

        verificationLogRepository.save(verificationLog);

        createNotification(
                getAdminUser(),
                updatedComplaint,
                "Complaint Verified",
                "A complaint has been verified and closed by " + verifiedBy.getFullName(),
                "VERIFIED"
        );

        return mapToComplaintResponseDto(updatedComplaint);
    }

    public ComplaintResponseDto reopenComplaint(Long complaintId, ComplaintVerificationDto dto) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User verifiedBy = getCurrentLoggedInUser();

        if (verifiedBy.getRole() != Role.TEACHER) {
            throw new RuntimeException("Only teachers can reopen complaints");
        }

        String oldStatus = complaint.getStatus().name();

        complaint.setStatus(ComplaintStatus.REOPENED);
        complaint.setIsVerified(false);

        Complaint updatedComplaint = complaintRepository.save(complaint);

        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaint(updatedComplaint)
                .oldStatus(oldStatus)
                .newStatus(ComplaintStatus.REOPENED.name())
                .changedBy(verifiedBy)
                .remarks(dto.getComments())
                .build();

        complaintStatusHistoryRepository.save(history);

        VerificationLog verificationLog = VerificationLog.builder()
                .complaint(updatedComplaint)
                .verifiedBy(verifiedBy)
                .verificationStatus(VerificationStatus.REOPENED)
                .comments(dto.getComments())
                .build();

        verificationLogRepository.save(verificationLog);

        createNotification(
                getAdminUser(),
                updatedComplaint,
                "Complaint Reopened",
                "A complaint has been reopened by " + verifiedBy.getFullName(),
                "REOPENED"
        );

        return mapToComplaintResponseDto(updatedComplaint);
    }

    public ComplaintResponseDto setExpectedResolutionDays(Long complaintId, ComplaintScheduleUpdateDto dto) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User admin = getCurrentLoggedInUser();

        if (admin.getRole() != Role.ADMIN) {
            throw new RuntimeException("Only admin can set expected resolution days");
        }

        complaint.setExpectedResolutionDays(dto.getExpectedResolutionDays());
        complaint.setExpectedResolutionDate(LocalDate.now().plusDays(dto.getExpectedResolutionDays()));

        Complaint updatedComplaint = complaintRepository.save(complaint);

        return mapToComplaintResponseDto(updatedComplaint);
    }

    public ComplaintResponseDto markComplaintDelayed(Long complaintId, DelayReasonDto dto) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User admin = getCurrentLoggedInUser();

        if (admin.getRole() != Role.ADMIN) {
            throw new RuntimeException("Only admin can mark complaint as delayed");
        }

        LocalDate oldExpectedDate = complaint.getExpectedResolutionDate();

        if (oldExpectedDate == null) {
            throw new RuntimeException("Expected resolution date is not set for this complaint");
        }

        String oldStatus = complaint.getStatus().name();
        LocalDate newExpectedDate = oldExpectedDate.plusDays(dto.getAdditionalDays());

        complaint.setStatus(ComplaintStatus.DELAYED);
        complaint.setExpectedResolutionDate(newExpectedDate);

        Complaint updatedComplaint = complaintRepository.save(complaint);

        ComplaintStatusHistory history = ComplaintStatusHistory.builder()
                .complaint(updatedComplaint)
                .oldStatus(oldStatus)
                .newStatus(ComplaintStatus.DELAYED.name())
                .changedBy(admin)
                .remarks(dto.getReason())
                .build();

        complaintStatusHistoryRepository.save(history);

        DelayLog delayLog = DelayLog.builder()
                .complaint(updatedComplaint)
                .delayedBy(admin)
                .oldExpectedDate(oldExpectedDate)
                .newExpectedDate(newExpectedDate)
                .reason(dto.getReason())
                .build();

        delayLogRepository.save(delayLog);

        createNotification(
                updatedComplaint.getReportedBy(),
                updatedComplaint,
                "Complaint Delayed",
                "Your complaint has been delayed. Reason: " + dto.getReason(),
                "DELAYED"
        );

        return mapToComplaintResponseDto(updatedComplaint);
    }

    public List<ComplaintResponseDto> getOverdueComplaints() {
        User admin = getCurrentLoggedInUser();

        if (admin.getRole() != Role.ADMIN) {
            throw new RuntimeException("Only admin can view overdue complaints");
        }

        return complaintRepository
                .findByExpectedResolutionDateBeforeAndStatusNot(LocalDate.now(), ComplaintStatus.CLOSED)
                .stream()
                .map(this::mapToComplaintResponseDto)
                .toList();
    }

    public List<NotificationResponseDto> getMyNotifications() {
        User user = getCurrentLoggedInUser();

        return notificationRepository.findByUserOrderByCreatedAtDesc(user)
                .stream()
                .map(this::mapToNotificationResponseDto)
                .toList();
    }

    public NotificationResponseDto markNotificationAsRead(Long notificationId) {
        User user = getCurrentLoggedInUser();

        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new RuntimeException("Notification not found with id: " + notificationId));

        if (!notification.getUser().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("You are not allowed to update this notification");
        }

        notification.setIsRead(true);

        Notification updatedNotification = notificationRepository.save(notification);

        return mapToNotificationResponseDto(updatedNotification);
    }

    public ComplaintImageResponseDto uploadComplaintImage(Long complaintId, MultipartFile file) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User user = getCurrentLoggedInUser();

        if (user.getRole() != Role.TEACHER) {
            throw new RuntimeException("Only teachers can upload complaint images");
        }

        if (!complaint.getReportedBy().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("You can upload images only for your own complaints");
        }

        if (file == null || file.isEmpty()) {
            throw new RuntimeException("Image file is required");
        }

        try {
            Path uploadPath = Paths.get(uploadDir);
            Files.createDirectories(uploadPath);

            String originalFilename = file.getOriginalFilename();
            String extension = "";

            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }

            String uniqueFileName = UUID.randomUUID() + extension;
            Path filePath = uploadPath.resolve(uniqueFileName);

            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            ComplaintImage complaintImage = ComplaintImage.builder()
                    .complaint(complaint)
                    .imagePath(filePath.toString())
                    .build();

            ComplaintImage savedImage = complaintImageRepository.save(complaintImage);

            createNotification(
                    getAdminUser(),
                    complaint,
                    "Complaint Image Uploaded",
                    "An image has been uploaded for complaint ID " + complaint.getComplaintId(),
                    "IMAGE_UPLOADED"
            );

            return mapToComplaintImageResponseDto(savedImage);

        } catch (IOException e) {
            throw new RuntimeException("Failed to upload image: " + e.getMessage());
        }
    }

    public List<ComplaintImageResponseDto> getComplaintImages(Long complaintId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new RuntimeException("Complaint not found with id: " + complaintId));

        User user = getCurrentLoggedInUser();

        if (user.getRole() == Role.TEACHER &&
                !complaint.getReportedBy().getUserId().equals(user.getUserId())) {
            throw new RuntimeException("You are not allowed to view images of this complaint");
        }

        return complaintImageRepository.findByComplaint_ComplaintId(complaintId)
                .stream()
                .map(this::mapToComplaintImageResponseDto)
                .toList();
    }
}