package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.VerificationLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VerificationLogRepository extends JpaRepository<VerificationLog, Long> {
}