package com.niet.campusissuesystem.controller;

import com.niet.campusissuesystem.dto.AuthResponseDto;
import com.niet.campusissuesystem.dto.LoginRequestDto;
import com.niet.campusissuesystem.entity.User;
import com.niet.campusissuesystem.enums.Role;
import com.niet.campusissuesystem.security.JwtUtil;
import com.niet.campusissuesystem.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final JwtUtil jwtUtil;

    public AuthController(AuthService authService, JwtUtil jwtUtil) {
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponseDto> login(@RequestBody LoginRequestDto dto) {
        User user = authService.login(dto);
        String token = jwtUtil.generateToken(user.getEmail());
        String role = user.getRole() == Role.ADMIN ? "admin" : "faculty";
        return ResponseEntity.ok(new AuthResponseDto(token, role, user.getFullName()));
    }
}