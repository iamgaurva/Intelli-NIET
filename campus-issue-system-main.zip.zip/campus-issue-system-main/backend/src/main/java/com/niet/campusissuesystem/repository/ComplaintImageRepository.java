package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.ComplaintImage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplaintImageRepository extends JpaRepository<ComplaintImage, Long> {
    List<ComplaintImage> findByComplaint_ComplaintId(Long complaintId);
}