package com.niet.campusissuesystem.enums;

public enum ComplaintStatus {
    SUBMITTED,
    UNDER_REVIEW,
    ASSIGNED,
    IN_PROGRESS,
    DELAYED,
    RESOLVED,
    REOPENED,
    CLOSED
}