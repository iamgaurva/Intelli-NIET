package com.niet.campusissuesystem.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ComplaintScheduleUpdateDto {

    @NotNull(message = "Expected resolution days is required")
    @Min(value = 1, message = "Expected resolution days must be at least 1")
    private Integer expectedResolutionDays;
}