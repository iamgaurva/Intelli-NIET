package com.niet.campusissuesystem.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class ComplaintImageResponseDto {

    private Long imageId;
    private Long complaintId;
    private String imagePath;
    private LocalDateTime uploadedAt;
}