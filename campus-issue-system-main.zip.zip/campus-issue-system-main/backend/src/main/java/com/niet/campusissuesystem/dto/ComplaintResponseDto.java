package com.niet.campusissuesystem.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class ComplaintResponseDto {

    private Long complaintId;
    private String complaintCode;
    private String complaintTitle;
    private String complaintDescription;

    private Long categoryId;
    private String categoryName;

    private Long locationId;
    private String blockName;
    private String floor;
    private String roomNumber;
    private String areaType;
    private String landmark;

    private Long reportedByUserId;
    private String reportedByName;
    private String reportedByEmail;
    private String reportedByRole;

    private String priority;
    private String status;
    private String assignedDepartment;

    private Integer expectedResolutionDays;
    private LocalDate expectedResolutionDate;
    private LocalDate actualResolutionDate;

    private String adminRemark;
    private Boolean isVerified;
    private String customCategory;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}