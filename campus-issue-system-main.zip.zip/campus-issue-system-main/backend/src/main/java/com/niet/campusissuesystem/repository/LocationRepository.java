package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Long> {
    java.util.Optional<Location> findByBlockNameIgnoreCaseAndFloorIgnoreCaseAndRoomNumberIgnoreCase(
            String blockName,
            String floor,
            String roomNumber
    );
}