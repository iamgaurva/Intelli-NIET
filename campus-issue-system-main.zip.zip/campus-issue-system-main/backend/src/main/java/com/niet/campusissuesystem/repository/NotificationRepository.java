package com.niet.campusissuesystem.repository;

import com.niet.campusissuesystem.entity.Notification;
import com.niet.campusissuesystem.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserOrderByCreatedAtDesc(User user);
}